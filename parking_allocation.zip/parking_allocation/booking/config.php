<?php

define('hostname', 'localhost');
define('user', 'root');
define('password', 'admin');
define('db_name', 'parking_allocation');


?>