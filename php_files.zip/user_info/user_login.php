<?php

include_once 'connection.php';
	
	class User {
		
		private $db;
		private $connection;
		
		function __construct() {
			$this -> db = new DB_Connection();
			$this -> connection = $this->db->getConnection();
		}
		
		public function does_user_exist($email,$password)
		{
			$query = "Select * from usertable where email='$email' and password = '$password' ";
			$result = mysqli_query($this->connection, $query);
			$res = mysqli_fetch_array($result);
			if(mysqli_num_rows($result)>0){
				$json['success'] = ' Welcome '.$res['username'];
				$json['user_id'] = $res['username'];
				echo json_encode($json);
				mysqli_close($this -> connection);
			}else{
				$json['error'] = 'Wrong email or password';
				echo json_encode($json);
				mysqli_close($this->connection);
			}
			
		}
		
	}
	
	
	$user = new User();
	if(isset($_POST['email'],$_POST['password'])) {
		$email = $_POST['email'];
		$password = $_POST['password'];
		
		if(!empty($email) && !empty($password)){
			
			$encrypted_password = md5($password);
			$user-> does_user_exist($email,$encrypted_password);
			
		}else{
			echo json_encode("You must type both inputs");
		}
		
	}












?>
