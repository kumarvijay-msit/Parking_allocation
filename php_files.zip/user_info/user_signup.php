<?php

include_once 'connection.php';
	
	class User{
		
		private $db;
		private $connection;
		
		function __construct() {
			$this -> db = new DB_Connection();
			$this -> connection = $this->db->getConnection();
		}
		
		public function signup($email,$password,$username,$mob_no)
		{
			$query = "insert into usertable (email, password, username, mob_no) values ( '$email','$password','$username','$mob_no')";
			$inserted = mysqli_query($this -> connection, $query);
			if($inserted == 1 ){
				$json['success'] = 'Acount created';
			}else{
				$json['error'] = 'Error';
			}
			echo json_encode($json);
			mysqli_close($this->connection);
			
		}
		
	}
	
	
	$user = new User();
	if(isset($_POST['username'],$_POST['password'],$_POST['email'],$_POST['mob_no'])) {
		$email = $_POST['email'];
		$password = $_POST['password'];
		$username = $_POST['username'];
		$mob_no = $_POST['mob_no'];
		
		if(!empty($email) && !empty($password) && !empty($username) && !empty($mob_no)){
			
			$encrypted_password = md5($password);
			$user-> signup($email,$encrypted_password,$username,$mob_no);
			
		}else{
			echo json_encode("You must enter all inputs");
		}
		
	}














?>
