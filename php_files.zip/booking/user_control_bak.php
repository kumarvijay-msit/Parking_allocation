<?php

include_once 'connection.php';
	
	class User {
		
		private $db;
		private $connection;
		
		function __construct() {
			$this -> db = new DB_Connection();
			$this -> connection = $this->db->getConnection();
		}
		
		public function submit_in_database($user_lat,$user_long,$dest_lat,$dest_long)
		{
			$query = "insert into bookinginfo (user_lat, user_long, dest_lat, dest_long) values ( '$user_lat','$user_long','$dest_lat','$dest_long')";
			$inserted = mysqli_query($this -> connection, $query);
			if($inserted == 1 ){
				$json['success'] = 'Success';
			}else{
				$json['error'] = 'Error';
			}
			echo json_encode($json);
			mysqli_close($this->connection);
		}		
	}
	
	
	$user = new User();
	if(isset($_POST['user_lat'],$_POST['user_long'],$_POST['dest_lat'],$_POST['dest_long'])) {
		$user_lat = $_POST['user_lat'];
		$user_long = $_POST['user_long'];
		$dest_lat = $_POST['dest_lat'];
		$dest_long = $_POST['dest_long'];
		$user-> submit_in_database($user_lat,$user_long,$dest_lat,$dest_long);
		
	}














?>
