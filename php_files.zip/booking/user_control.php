<?php

include_once 'connection.php';
	
	class User {
		
		private $db;
		private $connection;
		
		function __construct() {
			$this -> db = new DB_Connection();
			$this -> connection = $this->db->getConnection();
		}
		
		function GetDistance($lat1, $lat2, $long1, $long2)
		{
			$url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".$lat1.",".$long1."&destinations=".$lat2.",".$long2."&mode=driving&language=pl-PL";
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			$response = curl_exec($ch);
			curl_close($ch);
			$response_a = json_decode($response, true);
			$dist = $response_a['rows'][0]['elements'][0]['distance']['text'];
			//$time = $response_a['rows'][0]['elements'][0]['duration']['text'];

			return $dist;
		}
		
		public function submit_in_database($user_lat,$user_long,$dest_lat,$dest_long)
		{
			//Insertion of User and Dest Lat Long into database.
			$query = "insert into bookinginfo (user_lat, user_long, dest_lat, dest_long) values ( '$user_lat','$user_long','$dest_lat','$dest_long')";
			$inserted = mysqli_query($this -> connection, $query);
			
			//Fetching of Parking Lat Long from Database
			$query = "Select * from parking_slots";
			$result = mysqli_query($this->connection, $query);
			
			$min = 99999.0;
			
			//Calculating Distance b/w User Location and Parking Lots
			/*$dup = $this -> GetDistance($user_lat,$p_lat,$user_long,$p_long);
			$var_add = 0;
			$flag = 0;
			for( $i = 0; $i < strlen($dup); $i++ ) {
				$char = substr( $dup, $i, 1 );
				switch ($char){
					case " ": if(substr($dup, $i+1, 1 ) == "m") $var_add /= 1000; break;
					case "0":
					case "1":
					case "2":
					case "3":
					case "4":
					case "5":
					case "6":
					case "7":
					case "8":
					case "9": if ($flag == 0){
						$var_add *= 10;
						$var_add += $char;
					}
					else{
						$var_add += $char/10;
					}	
					break;
					case ",": $flag = 1; break;
					default: break;
				}
			}
			$dup = $var_add;
			
			//Calculating Distance b/w Destination and Parking Lots
			$ddp = $this -> GetDistance($dest_lat,$p_lat,$dest_long,$p_long);
			$var_add = 0;
			$flag = 0;
			for( $i = 0; $i < strlen($ddp); $i++ ) {
				$char = substr( $ddp, $i, 1 );
				switch ($char){
					case " ": if(substr($ddp, $i+1, 1 ) == "m") $var_add /= 1000; break;
					case "0":
					case "1":
					case "2":
					case "3":
					case "4":
					case "5":
					case "6":
					case "7":
					case "8":
					case "9": if ($flag == 0){
						$var_add *= 10;
						$var_add += $char;
					}
					else{
						$var_add += $char/10;
					}	
					break;
					case ",": $flag = 1; break;
					default: break;
				}
			}
			$ddp = $var_add;
			*/
			
			
			for ($j = 0; $j < mysqli_num_rows($result); $j++){
				$res = mysqli_fetch_array($result);
				$p_lat = $res['p_lat'];
				$p_long = $res['p_long'];
				
				if ($res['no_of_slots'] <= 0){
					continue;
				}
				//Calculating Distance b/w User Location and Parking Lots
				$dup = $this -> GetDistance($user_lat,$p_lat,$user_long,$p_long);
				$var_add = 0;
				$flag = 0;
				for( $i = 0; $i < strlen($dup); $i++ ) {
					$char = substr( $dup, $i, 1 );
					switch ($char){
						case " ": if(substr($dup, $i+1, 1 ) == "m") $var_add /= 1000; break;
						case "0":
						case "1":
						case "2":
						case "3":
						case "4":
						case "5":
						case "6":
						case "7":
						case "8":
						case "9": if ($flag == 0){
							$var_add *= 10;
							$var_add += $char;
						}
						else{
							$var_add += $char/10;
						}	
						break;
						case ",": $flag = 1; break;
						default: break;
					}
				}
				$dup = $var_add;
				
				//Calculating Distance b/w Destination and Parking Lots
				$ddp = $this -> GetDistance($dest_lat,$p_lat,$dest_long,$p_long);
				$var_add = 0;
				$flag = 0;
				for( $i = 0; $i < strlen($ddp); $i++ ) {
					$char = substr( $ddp, $i, 1 );
					switch ($char){
						case " ": if(substr($ddp, $i+1, 1 ) == "m") $var_add /= 1000; break;
						case "0":
						case "1":
						case "2":
						case "3":
						case "4":
						case "5":
						case "6":
						case "7":
						case "8":
						case "9": if ($flag == 0){
							$var_add *= 10;
							$var_add += $char;
						}
						else{
							$var_add += $char/10;
						}	
						break;
						case ",": $flag = 1; break;
						default: break;
					}
				}
				$ddp = $var_add;
				
				$x = 10 * $ddp + $dup;
				if ($x < $min){
					$min = $x;
					$final_id = $res['id'];
					$final_p_lat = $res['p_lat'];
					$final_p_long = $res['p_long'];
				}
			}
			//$json['success'] = 'Success'.$p_lat.' '.$p_long;
			if ($min != 99999.0){
				$json['success'] = 'Success'.' '.$final_p_lat.' '.$final_p_long;
				$json['lat'] = $final_p_lat;
				$json['long'] = $final_p_long;
				echo json_encode($json);
				$query = "update parking_slots set `no_of_slots` = `no_of_slots` - 1 where `id` = '$final_id'";
				$inserted = mysqli_query($this -> connection, $query);
			}
			else{
				$json['error'] = 'Sorry Parking Lots Full';
				echo json_encode($json);
			}
			mysqli_close($this->connection);
		}		
	}
	
	
	$user = new User();
	if(isset($_POST['user_lat'],$_POST['user_long'],$_POST['dest_lat'],$_POST['dest_long'])) {
		$user_lat = $_POST['user_lat'];
		$user_long = $_POST['user_long'];
		$dest_lat = $_POST['dest_lat'];
		$dest_long = $_POST['dest_long'];
		$user-> submit_in_database($user_lat,$user_long,$dest_lat,$dest_long);
		
	}














?>
